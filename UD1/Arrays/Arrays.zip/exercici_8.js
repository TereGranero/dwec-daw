/*
Ordena alfabèticament un vector de noms.
*/

let noms = ['María', 'Juan', 'Paco', 'Ursula', 'Anna'];
console.log(`Vector de noms: ${noms}`);

noms.sort(); 
console.log(`Noms ordenats: ${noms}`);;