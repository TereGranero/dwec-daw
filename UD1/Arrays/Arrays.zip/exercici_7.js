/*
A partir d'un vector de paraules genera un string amb totes les paraules unides.
*/

const array = ["Aquestes", "paraules", "formen", "una", "cadena"];
const string = array.join(' ');

console.log(`El vector: ${array}`);
console.log(`La cadena: ${string}`);

