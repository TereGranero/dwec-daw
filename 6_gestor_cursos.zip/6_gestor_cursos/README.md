# 6_gestor_cursos

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve

json-server --watch data/db.json --port 3000
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
